
#include <stdio.h>
#include <mpi.h>

int main(int argc, char **argv) {
    int rank, size;
    int data[17]; // uneven array
    int recv_data[5]; // Maximum any process will receive is 5 in this case
    int counts[4]; // Number of elements each process gets
    int displs[4]; // Starting index in data[] for each process

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int total_elements = 17;
    int base = total_elements / size; // 17 / 4 = 4
    int rem = total_elements % size;  // 17 % 4 = 1

    // Calculate counts for each process
    for (int i = 0; i < size; i++) {
        if (i < rem) {
            counts[i] = base + 1; // Process 0 gets 5 elements as 0 < 1
        } else {
            counts[i] = base;     // Other processes get 4 elements each
        }
    }

    // 
    displs[0] = 0;
    for (int i = 1; i < size; i++) {
        displs[i] = displs[i - 1] + counts[i - 1]; // Calculate starting index for each process //dis[1] = 0 +5 = 5 , dis[2] = 5 + 4 = 9, dis[3] = 9 + 4 = 13
    }

    // Initialize data in rank 0
    if (rank == 0) {
        for (int i = 0; i < total_elements; i++) {
            data[i] = i + 1;
        }
        
        printf("Original data in rank 0: ");
        for (int i = 0; i < total_elements; i++) {
            printf("%d ", data[i]);
        }
        printf("\n");
    }

    // Scatterv is used to scatter uneven data
    MPI_Scatterv(data, counts, displs, MPI_INT, recv_data, counts[rank], MPI_INT, 0, MPI_COMM_WORLD);

    // Print what each process received
    printf("Process %d received: ", rank);
    for (int i = 0; i < counts[rank]; i++) {
        printf("%d ", recv_data[i]);
    }
    printf("\n");

    // Multiply received data by 2
    for (int i = 0; i < counts[rank]; i++) {
        recv_data[i] *= 2;
    }

    // Print modified data in each process
    printf("Process %d after multiplication: ", rank);
    for (int i = 0; i < counts[rank]; i++) {
        printf("%d ", recv_data[i]);
    }
    printf("\n");

    // Gather all data back to rank 0
    MPI_Gatherv(recv_data, counts[rank], MPI_INT, data, counts, displs, MPI_INT, 0, MPI_COMM_WORLD);

    // Print final result in rank 0
    if (rank == 0) {
        printf("Final array in process 0: ");
        for (int i = 0; i < total_elements; i++) {
            printf("%d ", data[i]);
        }
        printf("\n");
    }

    MPI_Finalize();
    return 0;
}
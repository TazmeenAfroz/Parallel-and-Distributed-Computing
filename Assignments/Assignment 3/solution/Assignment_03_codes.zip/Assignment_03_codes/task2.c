#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc,char **argv){
    int rank,size;
    int data[16];
    int recv_data[4];
    int gathered_data[16];
    MPI_Init(&argc,&argv);
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
    MPI_Comm_size(MPI_COMM_WORLD,&size);

    if(rank == 0){
        // Initialize the array 
        for(int i = 0; i < 16; i++){
            data[i] = i + 1; 
        }
    }

    // Scatter the data to all processes
    MPI_Scatter(data, 4, MPI_INT, recv_data, 4, MPI_INT, 0, MPI_COMM_WORLD);
    // output the received data
    printf("Process %d received data: ", rank);
    for(int i = 0; i < 4; i++){
        printf("%d ", recv_data[i]);
    }
    printf("\n");
    // Each process multiplies its chunk by 
    for(int i = 0; i < 4; i++){
        recv_data[i] *= 2;
    }
    // Gather the updated data back to process 0
    MPI_Gather(recv_data, 4, MPI_INT, gathered_data, 4, MPI_INT, 0, MPI_COMM_WORLD);
    // Process 0 prints the final array
    if(rank == 0){
        printf("Final array in process 0: ");
        for(int i = 0; i < 16; i++){
            printf("%d ", gathered_data[i]);
        }
        printf("\n");
    }
    MPI_Finalize();
    return 0;


    
 }

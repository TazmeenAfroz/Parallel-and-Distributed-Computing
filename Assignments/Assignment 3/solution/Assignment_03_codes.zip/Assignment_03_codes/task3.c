#include <stdio.h>
#include <mpi.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    int rank, size, random_number, gathered_numbers[6], maximum, sum,average;
    double start_time, end_time, allgather_time, reduce_time, allreduce_time;
    int count = 0; 
    

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (size != 6) {
        if (rank == 0)
            printf("This program requires exactly 6 processes.\n");
        MPI_Finalize();
        return 1;
    }

    // Generate a random number between 1 and 100
    srand(rank + 1);  // Different seed for each process
    random_number = rand() % 100 + 1;
    printf("Process %d generated number: %d\n", rank, random_number);

    // Timing MPI_Allgather
    start_time = MPI_Wtime();
    // all gather the random numbers and store in gathered_numbers , all processes will have the same gathered_numbers
    MPI_Allgather(&random_number, 1, MPI_INT, gathered_numbers, 1, MPI_INT, MPI_COMM_WORLD);
    end_time = MPI_Wtime();
    allgather_time = end_time - start_time;

    // Print gathered numbers
    printf("Process %d gathered numbers: ", rank);
    for (int i = 0; i < size; i++) {
        printf("%d ", gathered_numbers[i]);
    }
    printf("\n");

 
    start_time = MPI_Wtime();
    // find the max no  from all processes and store in maximum 
    MPI_Reduce(&random_number, &maximum, 1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
    end_time = MPI_Wtime();
    reduce_time = end_time - start_time;

    // Print maximum from process 0
    if (rank == 0) {
        printf("Maximum number is: %d\n", maximum);
    }

    // Timing MPI_Allreduce to calculate sum and then compute average
    start_time = MPI_Wtime();
    MPI_Allreduce(&random_number, &sum, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);
    end_time = MPI_Wtime();
    allreduce_time = end_time - start_time;

    average = sum / size;

    // Output average and timings
    printf("Process %d average is: %d\n", rank, average);
    printf("Process %d Allgather time: %.6f seconds\n", rank, allgather_time);
    printf("Process %d Reduce time: %.6f seconds\n", rank, reduce_time);
    printf("Process %d Allreduce time: %.6f seconds\n", rank, allreduce_time);

    // Count of operations done
    printf("Process %d performed %d operations\n", rank, count);

    MPI_Finalize();
    return 0;
}

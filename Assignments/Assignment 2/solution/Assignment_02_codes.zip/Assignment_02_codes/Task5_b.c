#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char **argv) {
    int rank, process_count;
    double start_time, end_time;
    
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &process_count);
    
    int array[16];
    int elements_per_process = 16 / (process_count - 1);
    int remaining_elements = 16 % (process_count - 1);
    
    // Synchronize all processes before starting the timer
    MPI_Barrier(MPI_COMM_WORLD);
    
    // Start the timer
    start_time = MPI_Wtime();
    
    if(rank == 0) {
        for(int i = 0; i < 16; i++) {
            array[i] = i + 1;
        }
        printf("The original array is: ");
        for(int i = 0; i < 16; i++) {
            printf("%d ", array[i]);
        }
        printf("\n");
        
        // Arrays to manage asynchronous communication
        MPI_Request send_requests[process_count - 1];
        MPI_Request recv_requests[process_count - 1];
        
        // Distribute the array to all worker processes
        int start_index = 0;
        for(int i = 1; i < process_count; i++) {
            int count = elements_per_process;
            if(i <= remaining_elements) {
                count += 1;
            }
            MPI_Isend(&array[start_index], count, MPI_INT, i, 0, MPI_COMM_WORLD, &send_requests[i - 1]);
            start_index += count;
        }
        
        // Collect results from all worker processes
        start_index = 0;
        for(int i = 1; i < process_count; i++) {
            int count = elements_per_process;
            if(i <= remaining_elements) {
                count += 1;
            }
            MPI_Irecv(&array[start_index], count, MPI_INT, i, 1, MPI_COMM_WORLD, &recv_requests[i - 1]);
            start_index += count;
        }
        
        // Wait for all sends and receives to complete
        MPI_Waitall(process_count - 1, send_requests, MPI_STATUSES_IGNORE);
        MPI_Waitall(process_count - 1, recv_requests, MPI_STATUSES_IGNORE);
        
        // Print the results
        printf("The squares are: ");
        for(int i = 0; i < 16; i++) {
            printf("%d ", array[i]);
        }
        printf("\n");
    } else {
        // Worker processes receive their portion of the array
        int count = elements_per_process;
        if(rank <= remaining_elements) {
            count += 1;
        }
        int sub_array[count];
        MPI_Request recv_request, send_request;
        
        MPI_Irecv(sub_array, count, MPI_INT, 0, 0, MPI_COMM_WORLD, &recv_request);
        MPI_Wait(&recv_request, MPI_STATUS_IGNORE);
        
        // Compute the square of each value
        for(int i = 0; i < count; i++) {
            sub_array[i] = sub_array[i] * sub_array[i];
        }
        
        // Send the results back to the root process
        MPI_Isend(sub_array, count, MPI_INT, 0, 1, MPI_COMM_WORLD, &send_request);
        MPI_Wait(&send_request, MPI_STATUS_IGNORE);
    }
    
    // Synchronize all processes before stopping the timer
    MPI_Barrier(MPI_COMM_WORLD);
    
    // Stop the timer
    end_time = MPI_Wtime();
    
    // Print the execution time
    if (rank == 0) {
        printf("Task 2 (Non-blocking Communication) execution time: %f seconds\n", end_time - start_time);
    }
    
    MPI_Finalize();
    return 0;
}

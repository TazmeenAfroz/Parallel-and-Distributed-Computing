#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc , char **argv){
    int rank, process_count;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &process_count);
  
    int array[16];
    MPI_Request send_requests[process_count];
    MPI_Request recv_requests[process_count];

    if(rank == 0){
        for(int i = 0; i < 16; i++){
            array[i] = i + 1;
        }
        printf("The original array is: ");
        for(int i = 0; i < 16; i++){
            printf("%d ", array[i]);
        }
        printf("\n");
        
        for(int i = 1; i < process_count; i++){
            MPI_Isend(&array[i * 4], 4, MPI_INT, i, 0, MPI_COMM_WORLD, &send_requests[i]);
            MPI_Irecv(&array[i * 4], 4, MPI_INT, i, 1, MPI_COMM_WORLD, &recv_requests[i]);
        }
    } else {
        MPI_Irecv(&array[rank * 4], 4, MPI_INT, 0, 0, MPI_COMM_WORLD, &recv_requests[rank]);
        MPI_Wait(&recv_requests[rank], MPI_STATUS_IGNORE); // Ensure data is received before processing

        for(int i = rank * 4; i < (rank + 1) * 4; i++){
            array[i] = array[i] * array[i];
        }
        
        MPI_Isend(&array[rank * 4], 4, MPI_INT, 0, 1, MPI_COMM_WORLD, &send_requests[rank]);
    }

    if(rank == 0){
        MPI_Waitall(process_count - 1, recv_requests + 1, MPI_STATUSES_IGNORE); // Wait for all receives
        MPI_Waitall(process_count - 1, send_requests + 1, MPI_STATUSES_IGNORE); // Wait for all sends

        printf("The squares are: ");
        for(int i = 0; i < 16; i++){
            printf("%d ", array[i]);
        }
        printf("\n");
    } else {
        MPI_Wait(&send_requests[rank], MPI_STATUS_IGNORE); // Ensure send is complete
    }

    MPI_Finalize();
    return 0;
}
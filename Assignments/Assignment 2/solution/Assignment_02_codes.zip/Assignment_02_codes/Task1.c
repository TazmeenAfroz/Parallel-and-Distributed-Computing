#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc , char **argv){
    //rank - process id
    //process_count - number of processes
    //MPI_Init - initializes the MPI environment
    //MPI_Comm_rank - gets the rank of the process
    //MPI_Comm_size - gets the number of processes
   //MPI_COMM_WORLD - communicator that includes all processes
    int rank, process_count;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &process_count);
  
    int array[16];
    // Calculate the number of elements each worker process will handle
    //equally distribute the elements among the worker processes and if there are remaining elements, distribute them one by one to the first few processes
    int elements_per_process = 16 / (process_count - 1); 
    int remaining_elements = 16 % (process_count - 1);   

    if(rank == 0){
      
        for(int i = 0; i < 16; i++){
            array[i] = i + 1;
        }

        
        printf("The original array is: ");
        for(int i = 0; i < 16; i++){
            printf("%d ", array[i]);
        }
        printf("\n");
        // Distribute the array to all worker processes
        int start_index = 0;
        for(int i = 1; i < process_count; i++){
            int count = elements_per_process;
            if(i <= remaining_elements) {
                count += 1; // Add 1 if there are remaining elements becaue one process will have one more element
            }
            MPI_Send(&array[start_index], count, MPI_INT, i, 0, MPI_COMM_WORLD);
            start_index += count;
        }

        // Collect results from all worker processes    
        start_index = 0;
        for(int i = 1; i < process_count; i++){
            int count = elements_per_process;
            if(i <= remaining_elements) {
                count += 1; // Add 1 if there are remaining elements
            }
            MPI_Recv(&array[start_index], count, MPI_INT, i, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            start_index += count;
        }
                // Print the results
        printf("The squares are: ");
        for(int i = 0; i < 16; i++){
            printf("%d ", array[i]);
        }
        printf("\n");
    } else {
        // Worker processes receive their portion of the array
        int count = elements_per_process;
        if(rank <= remaining_elements) {
            count += 1; 
        }
        int sub_array[count];
        MPI_Recv(sub_array, count, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        // Compute the square of each value
        for(int i = 0; i < count; i++){
            sub_array[i] = sub_array[i] * sub_array[i];
        }

        // Send the results back to the root process
        MPI_Send(sub_array, count, MPI_INT, 0, 1, MPI_COMM_WORLD);
    }

    MPI_Finalize();
    return 0;
 }

// Workload Distribution: The workload is evenly distributed among worker processes, with extra elements assigned to the first few processes if the array size is not evenly divisible.
// // Scalability: The design can handle larger arrays but may face communication bottlenecks due to the root process

// The current design uses a single root process to coordinate all communication. This limits scalability because the root process cannot distribute or collect data in parallel.

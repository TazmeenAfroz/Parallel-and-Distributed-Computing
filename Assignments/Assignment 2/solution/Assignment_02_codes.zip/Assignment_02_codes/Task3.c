#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc , char **argv){
    int rank, process_count;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &process_count);

    // Write an MPI program with at least 4 processes, using the following logic: - Process 0 sends two arrays to Process 1 and 2. 
    // - Process 1 and 2 process the arrays and send results to Process 3. - Process 3 performs final aggregation and displays the result. 
    // 1. Use different tags for each message. 
    // 2. Use MPI_Status in receiving functions to determine source and tag dynamically. 
    

    int array1[4], array2[4];
    int result1[4], result2[4];
    int final_result[4];
    MPI_Status status;
    if(rank == 0){
        // Initialize the arrays
        for(int i = 0; i < 4; i++){
            array1[i] = i + 1;
            array2[i] =  i + 2;
        }
        // Send the arrays to Process 1 and Process 2
        MPI_Send(array1, 4, MPI_INT, 1, 0, MPI_COMM_WORLD);
        MPI_Send(array2, 4, MPI_INT, 2, 1, MPI_COMM_WORLD);
    } else if(rank == 1){
        // Receive the first array from Process 0
        MPI_Recv(array1, 4, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
        // Process the array (summing each element)
        for(int i = 0; i < 4; i++){
            result1[i] = array1[i]  + array1[i];
        }
        // Send the result to Process 3
        MPI_Send(result1, 4, MPI_INT, 3, 2, MPI_COMM_WORLD);
    } else if(rank == 2){
        // Receive the second array from Process 0
        MPI_Recv(array2, 4, MPI_INT, 0, 1, MPI_COMM_WORLD, &status);
        // Process the array (summing each element)
        for(int i = 0; i < 4; i++){
            result2[i] = array2[i] + array2[i];
        }
        // Send the result to Process 3
        MPI_Send(result2, 4, MPI_INT, 3, 3, MPI_COMM_WORLD);
    } else if(rank == 3){
        // Receive results from Process 1 and Process 2
        MPI_Recv(result1, 4, MPI_INT, 1, 2, MPI_COMM_WORLD, &status);
        MPI_Recv(result2, 4, MPI_INT, 2, 3, MPI_COMM_WORLD, &status);
        
        // Aggregate results 
        for(int i = 0; i < 4; i++){
            final_result[i] = result1[i] + result2[i];
        }
        
        // Display the final result
        printf("Final aggregated result: ");
        for(int i  = 0; i < 4; i++){
            printf("%d ", final_result[i]);
        }

        printf("\n");

    }
    MPI_Finalize();
    return 0;
}
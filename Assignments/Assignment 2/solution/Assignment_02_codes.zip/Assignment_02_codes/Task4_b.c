#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char **argv) {
    int world_rank, world_size;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    if (world_size < 4) {
        if (world_rank == 0) {
            printf("Error: This program requires at least 4 processes.\n");
        }
        MPI_Finalize();
        return 1;
    }

    int counter_forward = 0;
    int counter_backward = 0;
    int M = 2;
    int cycles_completed = 0;
    MPI_Status status;

    int next_rank = (world_rank + 1) % world_size;
    int prev_rank = (world_rank + world_size - 1) % world_size;

    if (world_rank == 0) {
        printf("Process %d: Starting bidirectional communication\n", world_rank);

        // Start both directions
        counter_forward++;
        counter_backward++;
        MPI_Send(&counter_forward, 1, MPI_INT, next_rank, 0, MPI_COMM_WORLD);
        MPI_Send(&counter_backward, 1, MPI_INT, prev_rank, 0, MPI_COMM_WORLD);

        while (cycles_completed < M) {
            // Receive from both sides
            MPI_Recv(&counter_backward, 1, MPI_INT, next_rank, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
            printf("Process %d: Received BACKWARD counter = %d from %d\n", world_rank, counter_backward, next_rank);

            MPI_Recv(&counter_forward, 1, MPI_INT, prev_rank, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
            printf("Process %d: Received FORWARD counter = %d from %d\n", world_rank, counter_forward, prev_rank);

            cycles_completed++;
            printf("Process %d: Completed cycle %d of %d\n", world_rank, cycles_completed, M);

            if (cycles_completed < M) {
                counter_forward++;
                counter_backward++;
                MPI_Send(&counter_forward, 1, MPI_INT, next_rank, 0, MPI_COMM_WORLD);
                MPI_Send(&counter_backward, 1, MPI_INT, prev_rank, 0, MPI_COMM_WORLD);
            }
        }

        // Termination signal in both directions
        MPI_Send(&counter_forward, 1, MPI_INT, next_rank, 1, MPI_COMM_WORLD);
        MPI_Send(&counter_backward, 1, MPI_INT, prev_rank, 1, MPI_COMM_WORLD);

    } else {
        while (1) {
            // BACKWARD direction
            MPI_Recv(&counter_backward, 1, MPI_INT, next_rank, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
            if (status.MPI_TAG == 1) {
                MPI_Send(&counter_backward, 1, MPI_INT, prev_rank, 1, MPI_COMM_WORLD);
                break;
            }
            printf("Process %d: Received BACKWARD counter = %d from %d\n", world_rank, counter_backward, next_rank);
            counter_backward++;
            MPI_Send(&counter_backward, 1, MPI_INT, prev_rank, 0, MPI_COMM_WORLD);

            // FORWARD direction
            MPI_Recv(&counter_forward, 1, MPI_INT, prev_rank, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
            if (status.MPI_TAG == 1) {
                MPI_Send(&counter_forward, 1, MPI_INT, next_rank, 1, MPI_COMM_WORLD);
                break;
            }
            printf("Process %d: Received FORWARD counter = %d from %d\n", world_rank, counter_forward, prev_rank);
            counter_forward++;
            MPI_Send(&counter_forward, 1, MPI_INT, next_rank, 0, MPI_COMM_WORLD);
        }
    }

    printf("Process %d: Terminating\n", world_rank);
    MPI_Finalize();
    return 0;
}
// Message Flow

//     Unidirectional: Message passes in one direction only.

//     Bi-directional: Messages flow in both directions — clockwise and counterclockwise.

// Counters

//     Unidirectional: One counter circulates the ring.

//     Bi-directional: Two counters move in opposite directions.

// Termination Logic

//     Unidirectional: Process 0 stops after one counter completes M cycles.

//     Bi-directional: Process 0 tracks both counters; terminates after both complete M cycles.

// Complexity

//     Unidirectional: Simple to implement and debug.

//     Bi-directional: More complex — must handle two counters and directions.

// Performance

//     Unidirectional: Slower due to single path usage.

//     Bi-directional: Faster with parallel message flow, but higher overhead.
#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>



int main(int argc, char **argv) {
    int world_rank, world_size;
    
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);
    
    // Check if we have enough processes
    if (world_size < 4) {
        if (world_rank == 0) {
            printf("Error: This program requires at least 4 processes.\n");
        }
        MPI_Finalize();
        return 1;
    }
    
   
    int counter = 0;
    int M = 2; // Number of complete cycles
    int cycles_completed = 0;
    MPI_Status status;
    
    // Define next and previous ranks
    // rank 1 then next rank = (0 + 1) % 4 = 1
    // rank 1 then prev rank = (0 + 4 - 1) % 4 = 3
    int next_rank = (world_rank + 1) % world_size;
    int prev_rank = (world_rank + world_size - 1) % world_size;
    
    
    if (world_rank == 0) {
        printf("Process %d: Starting counter with value %d\n", world_rank, counter);
        
        // Send initial counter
        counter++; // Increment 
        printf("Process %d: Sending counter with value %d to process %d\n", 
               world_rank, counter, next_rank);
        MPI_Send(&counter, 1, MPI_INT, next_rank, 0, MPI_COMM_WORLD);
        
        // Main loop for process 0
        while (cycles_completed < M) {
            // Receive the counter after a complete cycle
            MPI_Recv(&counter, 1, MPI_INT, prev_rank, 0, MPI_COMM_WORLD, &status);
            printf("Process %d: Received counter with value %d from process %d\n", 
                   world_rank, counter, prev_rank);
            
            // Increment cycles counter
            cycles_completed++;
            printf("Process %d: Completed cycle %d of %d\n", world_rank, cycles_completed, M);
            
            if (cycles_completed < M) {
                // Continue with another cycle
                counter++; // Increment counter
                printf("Process %d: Sending counter with value %d to process %d\n", 
                       world_rank, counter, next_rank);
                MPI_Send(&counter, 1, MPI_INT, next_rank, 0, MPI_COMM_WORLD);
            }
        }
        
        // Send termination message to next process after all cycles are complete
        printf("Process %d: All %d cycles completed, initiating termination\n", world_rank, M);
        MPI_Send(&counter, 1, MPI_INT, next_rank, 1, MPI_COMM_WORLD);
        
    } else {
        // Other processes just pass along the counter until terminated
        while (1) {
            // Receive message from previous process
            MPI_Recv(&counter, 1, MPI_INT, prev_rank, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
            
            // Check the tag to see if it's a termination message
            if (status.MPI_TAG == 1) {
                printf("Process %d: Received termination signal, forwarding to process %d\n", 
                       world_rank, next_rank);
                
                // Forward the termination message and exit the loop
                MPI_Send(&counter, 1, MPI_INT, next_rank, 1, MPI_COMM_WORLD);
                break;
            }
            
            // Regular counter message - process and forward
            printf("Process %d: Received counter with value %d from process %d\n", 
                   world_rank, counter, prev_rank);
            
            counter++; // Increment counter
            printf("Process %d: Sending counter with value %d to process %d\n", 
                   world_rank, counter, next_rank);
            MPI_Send(&counter, 1, MPI_INT, next_rank, 0, MPI_COMM_WORLD);
        }
    }
    
    printf("Process %d: Terminating\n", world_rank);
    MPI_Finalize();
    return 0;
}